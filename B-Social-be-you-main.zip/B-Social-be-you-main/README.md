# B-Social-be-you
Bsocial: Social Platform (Bootstrap, JS, PHP) Bsocial lets users connect and share. Built with Bootstrap, JS, and PHP.  Features:  User Accounts: Register with username, password, and optional details. Privacy: Control who sees your profile and posts . Friends: Connect with others and see their updates. and many more features !!!
